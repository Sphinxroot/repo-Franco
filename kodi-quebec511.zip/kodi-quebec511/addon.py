import sys

from resources.run_addon import run
run(sys.argv)